/_SDF09 OVERVIEW_/
For this project we were required to replicate the CodeSpace footer using our Tailwind and CSS knowledge.

I really enjoyed this section of CSS and using Tailwind as it is significantly faster than CSS and all the syntax is intuitive or easy to learn when it is not. I was able to get a hang of it quickly and recreated the CodeSpace footer with barely any trouble.

/_STRUGGLE_/
One of the only parts I struggled with when it came to this project was changing the horizontal padding or margins for the footer container as our size options were limited with "px-16" being the highest. This prevent me from creating a smaller container.

I also struggled to center the elements for smaller screens. I thought this could be done using "sm:mx-auto" but that failed to work.

I experienced some confusion with the constructions once or twice, where we were asked to change the colour of an element to imitate the image, but when i checked the code, the colour was already the same.

Apart from that, I really enjoyed this project.
